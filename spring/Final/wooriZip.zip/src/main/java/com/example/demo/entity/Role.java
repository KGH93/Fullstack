package com.example.demo.entity;

public enum Role {
    ADMIN, USER
}
