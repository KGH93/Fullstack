package com.example.demo.dto;

import lombok.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;

@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InteriorPostDto {
    private Long postId;
    private String title;
    private String content;

    private MultipartFile file; // 업로드용
    private String fileName;
    private String filePath;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    private String nickname;
    private Long userId;

    private int liked;
    private int views;
}