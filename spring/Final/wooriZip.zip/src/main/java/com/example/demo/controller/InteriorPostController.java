package com.example.demo.controller;

import com.example.demo.dto.InteriorPostDto;
import com.example.demo.service.InteriorPostService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@Controller
@RequiredArgsConstructor
@RequestMapping("/interior")
public class InteriorPostController {

    private final InteriorPostService service;

    /** 글 목록 */
    @GetMapping
    public String list(Model model) {
        model.addAttribute("posts", service.findAll());
        return "interior/list";
    }

    /** 글 작성 폼 */
    @GetMapping("/write")
    public String writeForm(Model model) {
        model.addAttribute("dto", new InteriorPostDto());
        return "interior/write";
    }

    /** 글 작성 처리 + 파일 업로드 포함 */
    @PostMapping("/write")
    public String write(@ModelAttribute InteriorPostDto dto) {
        handleFileUpload(dto);
        service.save(dto);
        return "redirect:/interior";
    }

    /** 상세 보기 + 조회수 증가 */
    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, Model model) {
        service.increaseViews(id);
        model.addAttribute("dto", service.findById(id));
        return "interior/detail";
    }

    /** 수정 폼 */
    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("dto", service.findById(id));
        return "interior/write";
    }

    /** 수정  */
    @PostMapping("/edit")
    public String edit(@ModelAttribute InteriorPostDto dto) {
        handleFileUpload(dto);
        service.save(dto);
        return "redirect:/interior/" + dto.getPostId();
    }

    /** 삭제 */
    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        service.delete(id);
        return "redirect:/interior";
    }

    /** 파일 업로드 처리 */
    private void handleFileUpload(InteriorPostDto dto) {
        MultipartFile file = dto.getFile();
        if (file != null && !file.isEmpty()) {
            try {
                String originalFileName = file.getOriginalFilename();
                String uploadDir = "src/main/resources/static/uploads/";
                File dir = new File(uploadDir);
                if (!dir.exists()) dir.mkdirs(); // 폴더 없으면 생성

                String savePath = uploadDir + originalFileName;
                file.transferTo(new File(savePath));

                dto.setFileName(originalFileName);
                dto.setFilePath("/uploads/" + originalFileName);
            } catch (IOException e) {
                e.printStackTrace(); // 실무에서는 로그 처리
            }
        }
    }
}
