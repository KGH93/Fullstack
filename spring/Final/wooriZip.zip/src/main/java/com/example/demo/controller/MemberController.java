package com.example.demo.controller;

import com.example.demo.dto.MemberDto;
import com.example.demo.entity.Member;
import com.example.demo.service.MemberService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
@RequestMapping("/member")
public class MemberController {

    private final MemberService memberService;

    @GetMapping("/signup")
    public String singupForm() {
        return "/member/signUp";
    }

    @PostMapping("/signup")
    public String signUp(@ModelAttribute MemberDto dto) {
        memberService.signUp(dto);
        return "redirect:/";
    }

    // [1] 로그인 페이지
    @GetMapping("/login")
    public String loginForm() {
        return "/member/login";
    }

    // [2] 로그인 처리
    @PostMapping("/login")
    public String login(@ModelAttribute MemberDto dto, HttpSession session, Model model) {
        Member member = memberService.login(dto.getUserId(), dto.getUserPw());
        if (member != null) {
            session.setAttribute("loginUser", member);
            return "redirect:/";  // 로그인 성공 시 메인 페이지로
        } else {
            model.addAttribute("error", "아이디 또는 비밀번호가 잘못되었습니다.");
            return "/member/login";
        }
    }

    // [3] 로그아웃
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
}
