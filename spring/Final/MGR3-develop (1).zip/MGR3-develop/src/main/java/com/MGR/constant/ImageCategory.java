package com.MGR.constant;

public enum ImageCategory {
    ATTRACTION,
    REVIEW,
    EVENT
}
