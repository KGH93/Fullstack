package com.MGR.constant;

public enum ReservationStatus {
    RESERVE, CANCEL, PAYED
}
