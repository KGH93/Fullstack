package com.MGR.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChatbotMessage {
    private String from;
    private String text;
}

