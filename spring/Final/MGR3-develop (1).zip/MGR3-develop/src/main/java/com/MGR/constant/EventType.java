package com.MGR.constant;

public enum EventType {
    EVENT,NOTICE
}
