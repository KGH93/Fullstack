package com.MGR.repository;

import com.MGR.entity.GoWithComment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GoWithCommentRepository extends JpaRepository<GoWithComment, Long> {
}
