package com.MGR.constant;

public enum Role {
    USER, ADMIN
}
