package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ProductListDto {
    private Long id;
    private String name;
    private int price;
    private String thumbnailUrl;
    private double averageRating;
    private int reviewCount;
}
