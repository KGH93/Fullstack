package BOARD.KGH;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KghApplicationTests {

	@Test
	void contextLoads() {
	}

}
