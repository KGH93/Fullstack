package BOARD.KGH.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MemberDTO {
    private String username;
    private String password;
}
