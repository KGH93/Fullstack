package BOARD.KGH;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KghApplication {

	public static void main(String[] args) {
		SpringApplication.run(KghApplication.class, args);
	}

}
