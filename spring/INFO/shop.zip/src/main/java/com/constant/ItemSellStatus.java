package com.constant;

public enum ItemSellStatus {
    SELL , SOLD_OUT
}
