package com.constant;

public enum Role {
    USER,ADMin
}
