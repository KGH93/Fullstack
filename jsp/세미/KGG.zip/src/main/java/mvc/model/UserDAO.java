package mvc.model;

public class UserDAO {

}
