//
//package mvc.model;
//
//public class Experience {
//    private String title;
//    private String imagePath;
//    private String dday;
//    private int views;
//    private int comments;
//    private int likes;
//    private String description;
//
//    // 생성자
//    public Experience(String title, String imagePath, String dday, int views, int comments, int likes, String description) {
//        this.title = title;
//        this.imagePath = imagePath;
//        this.dday = dday;
//        this.views = views;
//        this.comments = comments;
//        this.likes = likes;
//        this.description = description;
//    }
//
//    
//	public String getTitle() {
//		return title;
//	}
//
//	public void setTitle(String title) {
//		this.title = title;
//	}
//
//	public String getImagePath() {
//		return imagePath;
//	}
//
//	public void setImagePath(String imagePath) {
//		this.imagePath = imagePath;
//	}
//
//	public String getDday() {
//		return dday;
//	}
//
//	public void setDday(String dday) {
//		this.dday = dday;
//	}
//
//	public int getViews() {
//		return views;
//	}
//
//	public void setViews(int views) {
//		this.views = views;
//	}
//
//	public int getComments() {
//		return comments;
//	}
//
//	public void setComments(int comments) {
//		this.comments = comments;
//	}
//
//	public int getLikes() {
//		return likes;
//	}
//
//	public void setLikes(int likes) {
//		this.likes = likes;
//	}
//
//	public String getDescription() {
//		return description;
//	}
//
//	public void setDescription(String description) {
//		this.description = description;
//	}
//
//}
