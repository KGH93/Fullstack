package a0408.BicycleRentalSystem;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class AdminMenu extends AbstractMenu{
    private static final AdminMenu instance = new AdminMenu(null);
    private static List<Bicycle> bicycles = new ArrayList<>();

    private static final String ADMENU_TEXT =
        "1. 자전거 목록\n"+
        "2. 자전거 등록\n"+
        "3. 자전거 삭제\n"+
        "q: 종료\n"+
        "메뉴를 선택하세요 : ";

    private AdminMenu(Menu prevMenu){
        super(ADMENU_TEXT, prevMenu);
    }

    public static AdminMenu getInstance(){
        return instance;
    }

    @Override //어드민 오버라이드
    public Menu next() {
        switch (scan.nextLine()) {
            case "1"://자전거 목록
                ListBicycle();
                return this;
            case "2"://자전거 등록
                addBicycle();
                return this;
            case "3"://자전거 삭제
                deleteBicycle();
                return this;
            case "q"://관리자 메뉴 종료
                return prevMenu;  //이전 메뉴 이동
            default:
                System.out.println("잘못입력하셨습니다. 다시 입력해주세요.");
                return this;
        }
    }


    
    //자전거 목록 메서드
    private void ListBicycle() {
        try {
            List<Bicycle> bicycles = Bicycle.findAll();
            System.out.println("자전거 목록");
            if(bicycles.isEmpty()){
                System.out.println("등록된 자전거가 아닙니다.");
                return;
            }
            for (Bicycle bicycle : bicycles) {
                System.out.println(bicycle); // 각 자전거 정보를 한 줄씩 출력
            }
        } catch (Exception e) {
            System.out.println("조회 실패했습니다.");
        }
    }

    //자전거 등록 메서드
    private void addBicycle() {
        try {
            System.out.println("등록할 자전거 ID를 입력하세요 (숫자5자리):");
            String id = scan.nextLine();
            if(id.length()!=5){
                System.out.println("잘못된 ID형식입니다. 다시 입력해주세요.");
                return;
            }
            for (Bicycle bicycle : bicycles) {
                if (bicycle.getId().equals(id)) {
                    System.out.println("이미 존재하는 ID입니다. 다른 ID를 입력해주세요.");
                    return;
                }
            }
            Bicycle newbicycle = new Bicycle(id, BicycleStatus.AVAILABLE); //새 자전거 만들기
            Bicycle.add(newbicycle);
            System.out.println("신규 자전거 등록 완료");
        } catch (Exception e) {
            System.out.println("신규 자전거 등록 실패");
        }
    }


     
    //자전거 삭제 메서드
    private void deleteBicycle() {
        try {
            List<Bicycle> bicycles = Bicycle.findAll();
            if (bicycles.isEmpty()) {
                System.out.println("등록된 자전거가 없습니다.");
                return;
            }

            System.out.println("삭제할 자전거 ID를 입력하세요 (숫자5자리)");
            String idToDelete = scan.nextLine();

            if (idToDelete.length() != 5) {
                System.out.println("잘못된 입력입니다. 5자리 숫자를 입력해주세요.");
                return;
            }

            if (Bicycle.delete(idToDelete)) { // Bicycle 클래스의 delete 메서드 사용
                System.out.println("자전거가 삭제되었습니다.");
            } else {
                System.out.println("삭제 실패");
            }
        } catch (IOException e) {
            System.err.println("오류 발생");
        }
    }   

}
