private void rentBicycle(){
    try {
        // 여기 변경됨!
        System.out.println("대여 가능한 자전거 목록: ");
        int availableCount = 0;

        for (int i = 0; i < bicycles.size(); i++) {
            if (bicycles.get(i).getStatus() == BicycleStatus.AVAILABLE) {
                System.out.printf("%d: %s\n", i + 1, bicycles.get(i));
                availableCount++;
            }
        }

        if (availableCount == 0) {
            System.out.println("대여 가능한 자전가가 없습니다.");
            return;
        }

        System.out.println("대여 할 자전거 번호를 입력하세요 : ");
        int index = Integer.parseInt(scan.nextLine()) - 1;

        if (index < 0 || index >= bicycles.size()) {
            System.out.println("잘못된 번호입니다. 다시 입력해주세요.");
            return;
        }

        Bicycle selectBicycle = bicycles.get(index);
        selectBicycle.rent();
        selectBicycle.updateData(); // 대여 상태 저장
        System.out.println("대여 완료 했습니다.");
    } catch (NumberFormatException e) {
        System.out.println("잘못된 입력입니다. 숫자를 입력해주세요.");
    } catch (Exception e) {
        System.out.println("대여 실패 했습니다 ");
    } 
}