function generateRandomCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 10; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    document.getElementById("code").value = code;
}

function toggleDiscountInputs() {
    const amountInput = document.getElementById("amountInput");
    const percentInput = document.getElementById("percentInput");

    const typeAmount = document.getElementById("typeAmount").checked;
    const typePercent = document.getElementById("typePercent").checked;

    amountInput.style.display = typeAmount ? "block" : "none";
    percentInput.style.display = typePercent ? "block" : "none";
}

window.onload = toggleDiscountInputs;

// ✅ 쿠폰 활성화/비활성화 상태 토글 함수
function toggleCouponStatus(checkbox) {
    const couponId = checkbox.getAttribute('data-id');
    const newStatus = checkbox.checked ? 0 : 1; // 0: 활성화(true), 1: 비활성화(false)

    fetch(`/admin/coupons/${couponId}/status`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            // CSRF 토큰 사용 시 아래 줄 활성화
            // 'X-CSRF-TOKEN': document.querySelector('meta[name="_csrf"]').content
        },
        body: JSON.stringify({ isActive: newStatus })
    })
    .then(response => {
        if (!response.ok) throw new Error('상태 변경 실패');
        return response.json();
    })
    .then(data => {
        alert(`쿠폰이 ${newStatus === 0 ? '활성화' : '비활성화'} 상태로 변경되었습니다.`);
    })
    .catch(error => {
        alert('오류 발생: ' + error.message);
        checkbox.checked = !checkbox.checked; // 상태 복원
    });
}
