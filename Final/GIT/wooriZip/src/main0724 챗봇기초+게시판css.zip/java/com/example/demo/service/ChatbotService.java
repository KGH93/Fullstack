package com.example.demo.service;

import com.example.demo.dto.ChatbotResponseDto;
import com.example.demo.entity.Category;
import com.example.demo.entity.Product;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class ChatbotService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    public ChatbotResponseDto processMessage(String message) {
        String lowerMessage = message.toLowerCase().trim();
        
        // 상품 검색
        if (containsProductKeywords(lowerMessage)) {
            return handleProductSearch(lowerMessage);
        }
        
        // 카테고리 관련
        if (containsCategoryKeywords(lowerMessage)) {
            return handleCategoryInquiry(lowerMessage);
        }
        
        // 주문/배송 관련
        if (containsOrderKeywords(lowerMessage)) {
            return handleOrderInquiry(lowerMessage);
        }
        
        // 반품/교환 관련
        if (containsReturnKeywords(lowerMessage)) {
            return handleReturnInquiry(lowerMessage);
        }
        
        // 결제 관련
        if (containsPaymentKeywords(lowerMessage)) {
            return handlePaymentInquiry(lowerMessage);
        }
        
        // 이벤트 관련
        if (containsEventKeywords(lowerMessage)) {
            return handleEventInquiry(lowerMessage);
        }
        
        // 일반적인 인사
        if (containsGreetingKeywords(lowerMessage)) {
            return ChatbotResponseDto.builder()
                    .message("안녕하세요! 우리집 쇼핑몰 챗봇입니다. 무엇을 도와드릴까요?")
                    .type("text")
                    .suggestions(getCommonSuggestions())
                    .build();
        }
        
        // 기본 응답
        return ChatbotResponseDto.builder()
                .message("죄송합니다. 질문을 이해하지 못했습니다. 다른 방법으로 질문해 주시거나 아래 제안사항 중 하나를 선택해 주세요.")
                .type("text")
                .suggestions(getCommonSuggestions())
                .build();
    }

    private boolean containsProductKeywords(String message) {
        String[] keywords = {"상품", "제품", "가구", "소파", "테이블", "의자", "침대", "장식", "인테리어", "추천", "인기", "베스트"};
        return Arrays.stream(keywords).anyMatch(message::contains);
    }

    private boolean containsCategoryKeywords(String message) {
        String[] keywords = {"카테고리", "분류", "종류", "가격대", "스타일", "컬러", "색상", "재질"};
        return Arrays.stream(keywords).anyMatch(message::contains);
    }

    private boolean containsOrderKeywords(String message) {
        String[] keywords = {"주문", "배송", "배달", "택배", "언제", "도착", "배송비", "무료배송"};
        return Arrays.stream(keywords).anyMatch(message::contains);
    }

    private boolean containsReturnKeywords(String message) {
        String[] keywords = {"반품", "교환", "환불", "취소", "사이즈", "색상", "불만"};
        return Arrays.stream(keywords).anyMatch(message::contains);
    }

    private boolean containsPaymentKeywords(String message) {
        String[] keywords = {"결제", "카드", "무이자", "할부", "쿠폰", "할인", "포인트", "세일", "프로모션"};
        return Arrays.stream(keywords).anyMatch(message::contains);
    }

    private boolean containsGreetingKeywords(String message) {
        String[] keywords = {"안녕", "하이", "hello", "hi", "반가워", "처음"};
        return Arrays.stream(keywords).anyMatch(message::contains);
    }
    
    private boolean containsEventKeywords(String message) {
        String[] keywords = {"이벤트", "프로모션", "세일", "특가", "행사", "기념일"};
        return Arrays.stream(keywords).anyMatch(message::contains);
    }

    private ChatbotResponseDto handleProductSearch(String message) {
        List<Product> products = new ArrayList<>();
        String responseMessage = "";
        
        if (message.contains("소파") || message.contains("쇼파")) {
            products = productRepository.findByNameContainingIgnoreCase("소파");
            responseMessage = "소파 상품을 찾아드렸습니다.";
        } else if (message.contains("테이블")) {
            products = productRepository.findByNameContainingIgnoreCase("테이블");
            responseMessage = "테이블 상품을 찾아드렸습니다.";
        } else if (message.contains("의자")) {
            products = productRepository.findByNameContainingIgnoreCase("의자");
            responseMessage = "의자 상품을 찾아드렸습니다.";
        } else if (message.contains("침대")) {
            products = productRepository.findByNameContainingIgnoreCase("침대");
            responseMessage = "침대 상품을 찾아드렸습니다.";
        } else if (message.contains("인기") || message.contains("베스트") || message.contains("추천")) {
            // 인기 상품 (가격순으로 정렬하여 상위 5개)
            products = productRepository.findTop5ByOrderByPriceAsc();
            responseMessage = "인기 상품을 추천해드립니다.";
        } else {
            // 일반 상품 검색
            products = productRepository.findTop5ByOrderByCreatedAtDesc();
            responseMessage = "최신 상품을 보여드립니다.";
        }
        
        return ChatbotResponseDto.builder()
                .message(responseMessage)
                .type("product_list")
                .products(products)
                .link("/products")
                .build();
    }

    private ChatbotResponseDto handleCategoryInquiry(String message) {
        List<Category> categories = categoryRepository.findByParentIsNull();
        StringBuilder responseMessage = new StringBuilder("우리 쇼핑몰의 주요 카테고리입니다:\n");
        
        for (Category category : categories) {
            responseMessage.append("• ").append(category.getName()).append("\n");
        }
        
        return ChatbotResponseDto.builder()
                .message(responseMessage.toString())
                .type("text")
                .link("/products")
                .build();
    }

    private ChatbotResponseDto handleOrderInquiry(String message) {
        String responseMessage = "주문 및 배송 관련 안내입니다:\n\n" +
                "📦 배송 안내\n" +
                "• 배송 기간: 주문 후 2-3일 내 배송\n" +
                "• 배송비: 50,000원 이상 구매 시 무료배송\n" +
                "• 배송 지역: 전국 배송 가능\n\n" +
                "📋 주문 확인\n" +
                "• 주문 내역은 마이페이지에서 확인 가능\n" +
                "• 배송 조회는 주문번호로 조회 가능";
        
        return ChatbotResponseDto.builder()
                .message(responseMessage)
                .type("text")
                .link("/order/history")
                .build();
    }

    private ChatbotResponseDto handleReturnInquiry(String message) {
        String responseMessage = "반품/교환 안내입니다:\n\n" +
                "🔄 반품/교환 정책\n" +
                "• 반품 기간: 배송 완료 후 7일 이내\n" +
                "• 교환 기간: 배송 완료 후 14일 이내\n" +
                "• 반품비: 고객 부담 (단순 변심의 경우)\n\n" +
                "📞 문의\n" +
                "• 고객센터: 1588-0000\n" +
                "• 이메일: support@woorizip.com";
        
        return ChatbotResponseDto.builder()
                .message(responseMessage)
                .type("text")
                .build();
    }

    private ChatbotResponseDto handlePaymentInquiry(String message) {
        String responseMessage = "결제 안내입니다:\n\n" +
                "💳 결제 방법\n" +
                "• 신용카드, 체크카드\n" +
                "• 무이자 할부: 3개월, 6개월, 12개월\n" +
                "• 간편결제: 카카오페이, 네이버페이\n\n" +
                "🎫 할인 혜택\n" +
                "• 신규 가입 쿠폰: 10% 할인\n" +
                "• 생일 쿠폰: 15% 할인\n" +
                "• 포인트 적립: 구매 금액의 1%";
        
        return ChatbotResponseDto.builder()
                .message(responseMessage)
                .type("text")
                .link("/user/mypage")
                .build();
    }
    
    private ChatbotResponseDto handleEventInquiry(String message) {
        String responseMessage = "🎉 현재 진행 중인 이벤트입니다:\n\n" +
                "🎊 신규 가입 이벤트\n" +
                "• 가입 즉시 10,000원 할인 쿠폰 지급\n" +
                "• 첫 구매 시 추가 5% 할인\n\n" +
                "🎁 생일 축하 이벤트\n" +
                "• 생일 월에 15% 할인 쿠폰 지급\n" +
                "• 특별 선물 증정\n\n" +
                "📅 시즌 이벤트\n" +
                "• 봄맞이 가구 세일 (3월~4월)\n" +
                "• 여름 특가 이벤트 (7월~8월)\n" +
                "• 연말 감사제 (12월)";
        
        return ChatbotResponseDto.builder()
                .message(responseMessage)
                .type("text")
                .link("/event")
                .build();
    }

    public List<String> getCommonSuggestions() {
        return Arrays.asList(
                "인기 상품 추천해줘",
                "소파 상품 보여줘",
                "배송 안내 알려줘",
                "반품 정책 알려줘",
                "결제 방법 알려줘",
                "이벤트 정보 알려줘",
                "카테고리 보여줘"
        );
    }
} 