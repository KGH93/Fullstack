package com.example.demo.constant;

public enum CouponType {
    AMOUNT,
    PERCENT
}
