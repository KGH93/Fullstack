package com.example.demo.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RecommendLogController {
    @PostMapping("/recommend/log")
    public void logging(){

    }
}
