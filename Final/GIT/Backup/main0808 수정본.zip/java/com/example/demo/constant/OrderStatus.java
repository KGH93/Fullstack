package com.example.demo.constant;

public enum OrderStatus {
    // 결제대기 /  주문완료 /  주문 취소
    STAY,   // 결제하기 버튼 클릭
    ORDER,
    CANCEL,
}
