-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: woorizip
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product_image`
--

DROP TABLE IF EXISTS `product_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_image` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6oo0cvcdtb6qmwsga468uuukk` (`product_id`),
  CONSTRAINT `FK6oo0cvcdtb6qmwsga468uuukk` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_image`
--

LOCK TABLES `product_image` WRITE;
/*!40000 ALTER TABLE `product_image` DISABLE KEYS */;
INSERT INTO `product_image` VALUES (22,19,'/uploads/1753236153565_a001.jpg'),(23,20,'/uploads/1753236720730_a001.jpg'),(24,21,'/uploads/1753237047663_a001.jpg'),(25,22,'/uploads/1753237234522_a001.jpg'),(26,23,'/uploads/1753237331041_a001.jpg'),(27,24,'/uploads/1753237528722_a001.jpg'),(29,26,'/uploads/1753237677846_a001.jpg'),(30,27,'/uploads/1753237840037_a001.jpg'),(31,28,'/uploads/1753237982606_a001.jpg'),(32,29,'/uploads/1753249034731_a001.jpg'),(33,30,'/uploads/1753249178866_a001.jpg'),(35,32,'/uploads/1753249334682_a001.jpg'),(36,33,'/uploads/1753249518824_a001.jpg'),(37,31,'/uploads/1753249556834_a001.jpg'),(38,34,'/uploads/1753249612359_a001.jpg'),(39,35,'/uploads/1753249699640_a001.jpg'),(40,36,'/uploads/1753249754206_a001.jpg'),(41,37,'/uploads/1753249929765_a001.jpg'),(42,38,'/uploads/1753249983044_a001.jpg'),(43,39,'/uploads/1753250352203_a001.jpg'),(44,40,'/uploads/1753250941571_a001.jpg'),(45,41,'/uploads/1753251029894_a001.jpg'),(46,42,'/uploads/1753251244277_a001.jpg'),(47,43,'/uploads/1753251388559_a001.jpg'),(48,44,'/uploads/1753251434653_a001.jpg'),(56,52,'/uploads/1753689705097_a001.jpg'),(57,53,'/uploads/1753693035814_160922767017486785.jpg'),(59,55,'/uploads/1753762276741_a001.jpg'),(61,56,'/uploads/1753926837977_프로미스나인.jpg'),(62,57,'/uploads/1753929528722_하냥5.jpg'),(63,58,'/uploads/1753933281036_a0001.jpg'),(64,59,'/uploads/1753933493781_a0001.jpg'),(65,60,'/uploads/1753934301797_a0001.jpg'),(66,62,'/uploads/1753934699260_a0001.jpg'),(67,63,'/uploads/1753934789320_a0001.jpg'),(68,64,'/uploads/1753934986505_a0001.jpg'),(69,66,'/uploads/1753941331235_a001.jpg'),(70,67,'/uploads/1753942063176_a001.jpg'),(71,68,'/uploads/1753942272784_a001.jpg'),(72,69,'/uploads/1753942353051_a0001.jpg'),(73,70,'/uploads/1753944914619_a0001.png'),(74,71,'/uploads/1753945006999_a0001.jpg'),(75,72,'/uploads/1753945306366_a001.jpg'),(76,73,'/uploads/1753945391102_a001.jpg'),(77,74,'/uploads/1753945577328_a001.jpg'),(78,75,'/uploads/1753945661211_a001.jpg'),(79,76,'/uploads/1753945763883_a001.jpg'),(80,77,'/uploads/1753945881093_a001.jpg'),(81,78,'/uploads/1753946178075_168610145131641644.jpg'),(82,79,'/uploads/1753946256981_a001.jpg'),(83,80,'/uploads/1754101351317_a0001.jpg'),(84,81,'/uploads/1754366656668_oardefault.jpg'),(85,81,'/uploads/1754366703687_unnamed.jpg'),(86,81,'/uploads/1754366703688_프로미1.jpg'),(87,82,'/uploads/1754366822283_oardefault.jpg'),(88,83,'/uploads/1754380925230_프로미1.jpg'),(89,84,'/uploads/1754383193728_a001.jpg'),(90,85,'/uploads/1754383260471_a001.jpg'),(91,86,'/uploads/1754383427149_a001.jpg'),(92,87,'/uploads/1754383473790_a001.jpg'),(93,88,'/uploads/1754383563691_a001.jpg'),(94,89,'/uploads/1754383724520_a001.jpg'),(95,90,'/uploads/1754383835837_a001.jpg'),(96,91,'/uploads/1754383982428_a001.jpg'),(97,92,'/uploads/1754384042197_01.jpg'),(98,93,'/uploads/1754384119899_a001.jpg'),(99,94,'/uploads/1754384197018_a001.jpg'),(100,95,'/uploads/1754384344152_a001.jpg'),(101,96,'/uploads/1754384525268_a001.jpg'),(102,97,'/uploads/1754384566525_a001.jpg'),(103,98,'/uploads/1754384696604_a001.jpg'),(104,99,'/uploads/1754384782395_a001.jpg'),(106,101,'/uploads/1754384950488_a001.jpg'),(107,100,'/uploads/1754384991564_a001.jpg'),(108,102,'/uploads/1754385222594_a001.jpg'),(109,103,'/uploads/1754385325576_a001.jpg'),(110,104,'/uploads/1754385478681_a001.jpg');
/*!40000 ALTER TABLE `product_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-06  0:01:38
