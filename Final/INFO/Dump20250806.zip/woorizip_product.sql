-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: woorizip
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `average_rating` double NOT NULL,
  `price` int NOT NULL,
  `stock_quantity` int NOT NULL,
  `category_id` bigint DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK1mtsbur82frn64de7balymq9s` (`category_id`),
  KEY `FK47nyv78b35eaufr6aa96vep6n` (`user_id`),
  CONSTRAINT `FK1mtsbur82frn64de7balymq9s` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `FK47nyv78b35eaufr6aa96vep6n` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (0,10000,237,16,19,1,'마벨 욕실 화장대 인테리어 벽거울',NULL,NULL,0),(0,20000,90,16,20,1,'모던 팔각 원목 벽거울',NULL,NULL,0),(0,10000,82,16,21,1,'못없이 붙이는 무타공 욕실 화장대 원형거울 3size 3colors',NULL,NULL,0),(0,20000,200,15,22,1,'라운드 스탠드 전신거울 500 벽걸이 인테리어 거울 2color',NULL,NULL,0),(2,5000,90,17,23,1,'고급형 스테인 볼 미러 S 크롬 탁상 프레임 화장대 메탈 타원 거울 책상',NULL,NULL,0),(3,34000,102,13,24,1,'못없이 붙이는 무타공 벽선반',NULL,NULL,0),(0,43000,99,12,26,1,'메이저 1400 북선반북타워 책장 3colors',NULL,NULL,0),(0,350000,15,9,27,1,'올레스트 각도조절 리클라이너 소파안락의자 1인용소파',NULL,NULL,0),(0,800000,177,7,28,1,'메리 4인 무빙헤드레스트 가죽 소파 3colors',NULL,NULL,0),(0,680000,100,8,29,1,'노이 모듈 패브릭 1인 좌식 소파_H36',NULL,NULL,0),(0,90000,20,28,30,1,'나오미 7단 6단 1200 와이드 화장대 서랍장 거실장',NULL,NULL,0),(0,80000,40,29,31,1,'모노 높은 3단 서랍수납장 800 E0목재 LPM 다용도 슬림 서랍장',NULL,NULL,0),(0,190000,48,30,32,1,'메타 다용도 침대 선반 협탁 소파 사이드 테이블 3colors',NULL,NULL,0),(0,55000,220,19,33,1,'LR39HW 화이트바디 헤드형 컴퓨터 사무용 학생 공부 책상의자',NULL,NULL,0),(0,43000,30,21,34,1,'듀코 철제 스툴',NULL,NULL,0),(0,40000,150,20,35,1,'듀이 식탁 의자 플라스틱 카페 디자인의자',NULL,NULL,0),(4,38000,106,22,36,1,'LB01S 누비 등받이 허리 편한 자세교정 좌식의자',NULL,NULL,0),(0,100000,100,25,37,1,'레온 프리미엄 빅수납 호텔 침대',NULL,NULL,0),(0,59000,10,26,38,1,'침대 사이드 테이블 베드테이블 특대형',NULL,NULL,0),(0,190000,600,24,39,1,'미니피스 무헤드 3단 서랍 침대',NULL,NULL,0),(0,177000,50,4,40,1,'TSW 와이드 사무용 컴퓨터책상',NULL,NULL,0),(0,58000,90,3,41,1,'디디 반타원 테이블 라미네이트 화이트식탁 (7size)',NULL,NULL,0),(0,99000,60,5,42,1,'노트북 좌식테이블',NULL,NULL,0),(0,800000,40,33,43,1,'루카 슬라이딩 붙박이장 (30cm)',NULL,NULL,0),(0,260000,20,32,44,1,'무볼트 드레스룸 조립식 트리플행거',NULL,NULL,0),(0,100,12,7,52,1,'결제용 테스트',NULL,NULL,1),(0,10,9,36,53,1,'테스트 카테고리',NULL,NULL,1),(0,100,2,74,55,1,'ㅁㄴㅇㄹ',NULL,NULL,1),(0,10,10,74,56,1,'이미지수정',NULL,NULL,1),(0,1000,10,61,57,1,'결제 테스트',NULL,NULL,1),(0,5900,20,36,58,1,'머그컵 _ ON 데일리 컬러핸들 내열 유리머그 4P세트',NULL,NULL,0),(0,8000,60,37,59,1,'식판·나눔접시 _ 마일드 화이트 4절 나눔접시 대 22cm 2P_4P',NULL,NULL,0),(0,4000,240,38,60,1,'접시·플레이트 _ 니코트 에브리데이 컬렉션 둥근사각접시 세트 2P',NULL,NULL,0),(0,0,0,40,61,1,'OYEAH 알루미늄 합금 세라믹 냄비 2종 세트 - 냄비세트',NULL,NULL,1),(0,36000,50,41,62,1,'OYEAH 알루미늄 합금 세라믹 냄비 2종 세트 - 냄비세트 ',NULL,NULL,0),(0,40000,20,40,63,1,'셰프라인 CP 프라이팬, 28cm, 2개 - 일반프라이팬',NULL,NULL,0),(0,12000,40,42,64,1,'키친하우스 프라임 스텐국자 - 국자',NULL,NULL,0),(0,0,0,41,65,1,'d',NULL,NULL,1),(0,34000,300,45,66,1,'루체르 맞춤 100% 빛차단 방한 방풍 린넨 암막커튼 핀형아일렛형 10색상',NULL,NULL,0),(0,30000,90,49,67,1,'비정형 워셔블 온감 러그 단모 사계절 뭉게구름 카페트',NULL,NULL,0),(0,60000,150,53,68,1,'빌리프 알러지케어 항균 사계절 꿀잠 매트리스 토퍼',NULL,NULL,0),(0,250000,80,58,69,1,'[최신형] 차이슨 무선 스틱 청소기 BLDC 흡입력 좋은 진공청소기 + 다양한 구성품 + 평생AS - 스틱청소기',NULL,NULL,0),(0,5000,50,56,70,1,'채움리빙 채움비 빗자루 세트 A - 빗자루_쓰레받기',NULL,NULL,0),(0,7000,80,57,71,1,'코멧 다용도 밀대걸레 + 극세사 걸레 3개입 - 밀대_밀대포세트',NULL,NULL,0),(0,16000,100,64,72,1,'LED 무선 수면등 수유등 감성 스탠드 수오모 무드등',NULL,NULL,0),(0,32000,50,67,73,1,'뉴 클림트 플로어램프 장스탠드',NULL,NULL,0),(0,10000,150,71,74,1,'LED 에코 어반 2인치 3인치 4인치 움푹 다운라이트',NULL,NULL,0),(0,3000,50,80,75,1,'핸드메이드 호텔 디퓨저 세트 OBJET LINE 대용량 2L',NULL,NULL,0),(0,27000,50,78,76,1,'팝 미러클락 빅 LED 탁상시계',NULL,NULL,0),(0,20000,150,74,77,1,'폴라로이드  포카 액자 프레임 6종 - 웨딩액자 가족액자 취향액자',NULL,NULL,0),(0,8000,50,85,78,1,'모노 논슬립 라운딩 옷걸이',NULL,NULL,0),(0,9900,50,87,79,1,'이동식 트롤리 4단 수납장 서랍장',NULL,NULL,0),(5,100,210,38,80,1,'0802 테스트',NULL,NULL,1),(0,100,30,78,81,1,'0805 상품입니다.',NULL,NULL,1),(0,100,22,64,82,1,'송하빵',NULL,NULL,1),(0,10000,300,30,83,1,'의자',NULL,NULL,1),(0,1000,90,3,84,1,'미드센추리 페이트 아치형 스탠드 전신거울',NULL,NULL,0),(0,1000,70,3,85,1,'플한 슬림베젤 라운드 스탠딩 벽걸이 400 전신거울',NULL,NULL,0),(0,13000,200,5,86,1,'내츄럴 우드 데일리 탁상거울',NULL,NULL,0),(0,17000,100,5,87,1,'타원 좌경 대 스탠드 원형 화장대 거울',NULL,NULL,0),(0,6000,100,9,88,1,'아치형 우드 슬림 미니 벽걸이 1단 선반',NULL,NULL,0),(0,25000,120,9,89,1,'인테리어 벽선반 원목 벽걸이 무지주선반',NULL,NULL,0),(0,55000,100,7,90,1,'VT 시그니처 원목 피렉장',NULL,NULL,0),(0,60000,50,8,91,1,'바턴 36T 1200 5단 책장 책꽂이',NULL,NULL,0),(0,77000,150,13,92,1,'올프리 생활발수 패브릭 1인용 리클라이너 소파+스툴',NULL,NULL,0),(0,230000,100,13,93,1,'포엠 USB 3인용 전동 리클라이너 가죽소파',NULL,NULL,0),(0,400000,150,11,94,1,'카이 가죽 3인 소파',NULL,NULL,0),(0,2100000,100,11,95,1,'톰 클래식 구스 아쿠아텍스 패브릭 모듈 소파 4인용',NULL,NULL,0),(0,89000,100,12,96,1,'모니 패브릭 1인 좌식 쇼파 각도조절 좌식의자 원룸인테리어',NULL,NULL,0),(0,800000,100,12,97,1,'코니아 3인용 좌식소파 소파베드 2colors',NULL,NULL,0),(0,60500,200,22,98,1,'피트 미드센츄리 빈티지 캐비넷 서랍장 수납장',NULL,NULL,0),(0,10000,300,22,99,1,'헬메르 철제 이동식서랍장 책상밑',NULL,NULL,0),(0,99000,50,23,100,1,'샤인 분리수거장 스윙 수납장',NULL,NULL,0),(0,145000,50,23,101,1,'철제 슬림 콘솔 미닫이 수납장',NULL,NULL,0),(0,69000,100,24,102,1,'베르 고무나무 심플 원목 미니 침대 옆 협탁 선반',NULL,NULL,0),(0,33000,100,24,103,1,'크나레비크 협탁 사이드테이블',NULL,NULL,0),(0,37000,200,30,104,1,'베가 듀이 코듀로이 패브릭 인테리어 접이식 의자 5colors',NULL,NULL,0);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-06  0:01:38
