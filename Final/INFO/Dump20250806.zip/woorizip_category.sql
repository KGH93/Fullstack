-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: woorizip
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `depth` int NOT NULL,
  `id` bigint NOT NULL,
  `parent_id` bigint DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK46ccwnsi9409t36lurvtyljak` (`name`),
  KEY `FK2y94svpmqttx80mshyny85wqr` (`parent_id`),
  CONSTRAINT `FK2y94svpmqttx80mshyny85wqr` FOREIGN KEY (`parent_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (0,1,NULL,'가구'),(1,2,1,'거울'),(2,3,2,'전신거울'),(2,4,2,'벽거울'),(2,5,2,'탁상거울'),(1,6,1,'진열장.책장.선반'),(2,7,6,'진열장'),(2,8,6,'책장'),(2,9,6,'선반'),(1,10,1,'소파'),(2,11,10,'일반소파'),(2,12,10,'좌식소파'),(2,13,10,'리클라이너'),(1,14,1,'테이블.식탁.책상'),(2,15,14,'식탁'),(2,16,14,'사무용책상'),(2,17,14,'좌식책상'),(1,18,1,'행거.붙박이장'),(2,19,18,'행거'),(2,20,18,'붙박이장'),(1,21,1,'서랍.수납장'),(2,22,21,'서랍'),(2,23,21,'수납장'),(2,24,21,'협탁'),(1,25,1,'침대'),(2,26,25,'침대프레임'),(2,27,25,'침대+매트리스'),(2,28,25,'침대부속가구'),(1,29,1,'의자'),(2,30,29,'학생.사무용의자'),(2,31,29,'식탁의자'),(2,32,29,'스툴'),(2,33,29,'좌식의자'),(0,34,NULL,'주방용품'),(1,35,34,'식기'),(2,36,35,'접시'),(2,37,35,'그릇'),(2,38,35,'컵'),(1,39,34,'조리도구'),(2,40,39,'프라이팬'),(2,41,39,'냄비'),(2,42,39,'국자'),(0,43,NULL,'패브릭'),(1,44,43,'커튼'),(2,45,44,'암막커튼'),(2,46,44,'레이스커튼'),(1,47,43,'러그'),(2,48,47,'주방러그'),(2,49,47,'거실러그'),(1,50,43,'침구'),(2,51,50,'이불'),(2,52,50,'베개커버'),(2,53,50,'패드'),(0,54,NULL,'생활용품'),(1,55,54,'청소용품'),(2,56,55,'빗자루'),(2,57,55,'밀대'),(2,58,55,'청소기부속'),(1,59,54,'욕실용품'),(2,60,59,'샤워커튼'),(2,61,59,'디스펜서'),(0,62,NULL,'조명'),(1,63,62,'무드등'),(2,64,63,'USB무드등'),(2,65,63,'캔들형무드등'),(1,66,62,'스탠드'),(2,67,66,'장스탠드'),(2,68,66,'단스탠드'),(1,69,62,'천장등'),(2,70,69,'펜던트등'),(2,71,69,'LED등'),(0,72,NULL,'인테리어소품'),(1,73,72,'액자'),(2,74,73,'벽걸이액자'),(2,75,73,'탁상액자'),(1,76,72,'시계'),(2,77,76,'벽시계'),(2,78,76,'탁상시계'),(1,79,72,'디퓨저'),(2,80,79,'스틱형'),(2,81,79,'자동분사형'),(0,82,NULL,'수납/정리'),(1,83,82,'옷걸이'),(2,84,83,'문걸이'),(2,85,83,'다용도걸이'),(1,86,82,'정리함'),(2,87,86,'서랍형'),(2,88,86,'뚜껑형');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-06  0:01:38
