-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: woorizip
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `qna_post`
--

DROP TABLE IF EXISTS `qna_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `qna_post` (
  `created_at` datetime(6) DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `file_names` varchar(255) DEFAULT NULL,
  `file_paths` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `is_secret` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKe099r9muw4v4n5l53pyebtngm` (`product_id`),
  CONSTRAINT `FKe099r9muw4v4n5l53pyebtngm` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qna_post`
--

LOCK TABLES `qna_post` WRITE;
/*!40000 ALTER TABLE `qna_post` DISABLE KEYS */;
INSERT INTO `qna_post` VALUES ('2025-07-28 18:06:00.376496',3,53,'2025-07-30 16:32:11.921258','이거이거맞아?ㅁㄴㅇㄹ','kakao@naver.com','','','까까오','카테고리 이거 맞아요??',_binary ''),('2025-08-02 11:34:20.375693',4,75,'2025-08-02 11:34:20.375693','삭제삭제','test@naver.com','imgi_366_v1-363431874048128.png','/uploads/09890b99-8123-4271-8b80-0ca707e0e1cd_imgi_366_v1-363431874048128.png','베타','욕욕욕',_binary ''),('2025-08-02 11:51:04.044649',5,23,'2025-08-02 11:51:04.045633','d','test@naver.com','133851060505754111.jpg','/uploads/c6acdec4-4bc4-4f04-8703-c20832f973b2_133851060505754111.jpg','베타','d',_binary '\0'),('2025-08-05 12:50:04.779661',6,80,'2025-08-05 12:50:16.108587','여깃소 비밀글이오','test2@naver.com','프로미1.jpg','/uploads/a5f9be99-7ddc-42ef-a600-7a081218765d_프로미1.jpg','삭제용','나 김삿갓',_binary ''),('2025-08-05 16:59:16.880659',7,80,'2025-08-05 16:59:32.206724','내용','test2@naver.com','133843118947920483.jpg','/uploads/6f2169fd-9fe4-4f99-9572-3523c1ba5d1f_133843118947920483.jpg','삿갓을쓰자','제목 - 관리자',_binary '');
/*!40000 ALTER TABLE `qna_post` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-06  0:01:39
