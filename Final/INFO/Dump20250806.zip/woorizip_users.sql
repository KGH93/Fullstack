-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: woorizip
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `birth` date DEFAULT NULL,
  `residence_type` int NOT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `detail_addr` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `extra_addr` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `load_addr` varchar(255) NOT NULL,
  `lot_addr` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `p_code` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `social` varchar(255) DEFAULT NULL,
  `user_pw` varchar(255) DEFAULT NULL,
  `role` enum('ADMIN','USER') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('1999-11-11',0,1,'2층','1@naver.com',' (구로동)','m','서울 구로구 디지털로 306','서울 구로구 구로동 182-13','원펀치','원펀치','08378','01007092025',NULL,'$2a$10$1g4nOZPaBPzhLnZdVH.S0eqM13GFgHWIv84PUvwRQkB7wHPL3RPdi','ADMIN'),('1997-03-02',1,2,'2층','kakao@naver.com',' (구로동)','f','서울 구로구 디지털로 306','서울 구로구 구로동 182-13','카카오','까까오','08378','01022223333',NULL,'$2a$10$iT0gjMorIlcw2ZRdhAQ61uE76H72qpIE7fe1OzPmXrK4.q.CZhGU6','USER'),('2025-07-29',0,3,'','dong110999@gmail.com','','','','','이동근','이동근','','','google','','USER'),('2001-01-08',1,4,'301','test@naver.com',' (신사동)','f','서울 강남구 가로수길 13','3층','테스터','베타','06035','01077778521',NULL,'$2a$10$A95HO.niycmZAaVq4mnsk.Pmw/ACXhK3Xv15XaYX1hDIbBlH4/nKK','USER'),('2000-10-10',1,5,'2층','test2@naver.com',' (교현동)','m','충북 충주시 여수월1길 1-1','충북 충주시 교현동 472-63','김삿갓','삿갓을쓰자','27373','01008050000',NULL,'$2a$10$1VfoT2EC.8B/ghAE2cnMbeYRx197/SvdhRIzgOFjEYwHlPJNBLWMa','USER'),('1999-01-01',0,6,'101','qwe@email.com',' (구로동)','m','서울 구로구 디지털로 306','서울 구로구 구로동 182-13','유저1','유저1','08378','01011111111',NULL,'$2a$10$nhmpOgOOrE2Vy19MsZ1EjegGKBNuJrISDcyOdBJQjcxitH8ZUiGUi','USER'),('2000-03-03',2,7,'102','asd@email.com',' (구로동)','m','서울 구로구 디지털로 306','서울 구로구 구로동 182-13','유저2','유저2','08378','01022222222',NULL,'$2a$10$rE2FbUXgtWDdSntdJlHwu.PeN5qhOo0HWb/qcgvEgY2GrGFLnxY36','USER'),('2001-04-23',1,8,'103','zxc@email.com',' (구로동)','m','서울 구로구 디지털로 306','서울 구로구 구로동 182-13','유저3','유저3','08378','01044444444',NULL,'$2a$10$E3Ok1/tQMn1kd.l6ttBXC.iViDvCYDqYALjxjVDOlfxxHHG8b/EO.','USER'),('2003-04-11',0,9,'201','wer@email.com',' (구로동)','m','서울 구로구 디지털로 306','서울 구로구 구로동 182-13','유저4','유저4','08378','01055555555',NULL,'$2a$10$C7Xr1y/eyUC87MgzXLqL3OdW/t2srGL1.t0MRPYIy3B5i2/lAGvGW','USER'),('2005-08-03',1,10,'202','sdf@email.com',' (구로동)','f','서울 구로구 디지털로 306','서울 구로구 구로동 182-13','유저5','유저5','08378','01012311234',NULL,'$2a$10$55jueeINC2uhiQxdAc.WBexTBagyKV.OX83tmw30ypjbj2czfxsUm','USER'),('1999-07-02',2,11,'203','xcv@email.com',' (구로동)','f','서울 구로구 디지털로 306','서울 구로구 구로동 182-13','유저6','유저6','08378','01012322341',NULL,'$2a$10$mevH.LQc.LXWpKKHFQlSjO1ycCS4V9b7XbHxE2vNKd.KbDUdTdJPC','USER');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-06  0:01:39
