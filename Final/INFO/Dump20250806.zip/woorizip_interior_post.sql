-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: woorizip
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `interior_post`
--

DROP TABLE IF EXISTS `interior_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interior_post` (
  `liked` int NOT NULL,
  `views` int NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `post_id` bigint NOT NULL AUTO_INCREMENT,
  `updated_at` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `content` text,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `is_notice` bit(1) NOT NULL,
  PRIMARY KEY (`post_id`),
  KEY `FKsjwf16oor631gjrd76jqf7hpj` (`user_id`),
  CONSTRAINT `FKsjwf16oor631gjrd76jqf7hpj` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interior_post`
--

LOCK TABLES `interior_post` WRITE;
/*!40000 ALTER TABLE `interior_post` DISABLE KEYS */;
INSERT INTO `interior_post` VALUES (1,1,'2025-07-30 16:26:47.167063',8,'2025-07-30 16:29:02.972014',1,'7월 럭키세븐 쿠폰 7퍼가 아닌 3퍼 더 얹혀서 10퍼 할인','1753860407157_하냥5.jpg','/uploads/1753860407157_하냥5.jpg','7월 말 대이벤트',_binary ''),(0,1,'2025-08-02 11:48:17.953709',10,'2025-08-02 11:48:29.815813',1,'뿌린다.','1754102897947_프로미1.jpg','/uploads/1754102897947_프로미1.jpg','8월 블랙프라이데이 기념 할인 쿠폰',_binary ''),(0,1,'2025-08-05 17:06:15.037007',13,'2025-08-05 17:06:20.190082',1,'공지사항1','1754381175028_v1-287536057872384.jpg','/uploads/1754381175028_v1-287536057872384.jpg','공지 사항',_binary '');
/*!40000 ALTER TABLE `interior_post` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-06  0:01:39
